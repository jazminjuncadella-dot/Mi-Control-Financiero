MI CONTROL FINANCIERO v2

Novedades:
- Conejitos como mascota visual.
- Deudas con saldo, pago mensual y fecha límite.
- Gastos fijos.
- Disponible real: ingresos - egresos - gastos fijos - pagos de deuda.
- Perfiles editables: agregar/quitar Jaz, Manuel, Casa u otros.
- Categorías editables.
- Colores de fondo personalizables con presets y selector manual.
- Conserva el mismo package Android para instalarse como actualización sobre v1.
- Conserva el mismo almacenamiento local para intentar mantener los datos existentes.
