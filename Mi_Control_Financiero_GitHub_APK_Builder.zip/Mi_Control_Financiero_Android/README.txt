MI CONTROL FINANCIERO — PROYECTO ANDROID

Este proyecto abre la app financiera como una aplicación Android independiente,
con icono propio y almacenamiento local en el dispositivo.

Para generar el APK:
1. Abre esta carpeta en Android Studio.
2. Espera a que Gradle sincronice.
3. Ve a Build > Build Bundle(s) / APK(s) > Build APK(s).
4. El APK quedará en app/build/outputs/apk/debug/app-debug.apk.

Paquete Android:
com.jaz.controlfinanciero

La interfaz incluida es la versión pastel rosa, morado y azul con:
- ingresos/egresos
- diario/semanal/mensual
- Jaz/Manuel/Casa
- presupuesto
- metas
- estadísticas
- guardado local